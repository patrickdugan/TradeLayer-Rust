"""Work-only ClearList fragment for the future MainCallableV8 Core."""
from pathlib import Path
STAGE=Path(__file__).resolve().parent
def one(s,a,b):
    if s.count(a)!=1:raise ValueError(f'ClearList anchor count {s.count(a)}: {a[:90]}')
    return s.replace(a,b,1)
def prepare_owner(s):
    if 'source_clearlist_pure_unverified' in s:raise ValueError('ClearList bridge already mounted')
    return s+'''
/// Stateless reuse of verified source pure helpers. No rows or owner are created.
pub(crate) fn source_clearlist_pure_unverified(method:&str,args:&[V])->Result<SourceOutcome,SourceRuleError>{
    let result=(||->Eval<V>{match method{
        "verifyMerkleProof"=>Ok(V::Bool(verify_proof(&arg(args,0),&arg(args,1),&arg(args,2))?)),
        "buildMerkleTree"=>build_tree(&arg(args,0)),
        "generateMerkleProof"=>generate_proof(&arg(args,0),&arg(args,1)),
        "sortHistory"=>{let mut rows=array(&arg(args,0))?.to_vec();sort_history(&mut rows)?;Ok(V::Array(rows))},
        _=>Err(SourceRuleError::UnknownMethod.into()),
    }})();
    match result{Ok(v)=>Ok(SourceOutcome::Returned(v)),Err(Fault::Thrown(e))=>Ok(SourceOutcome::Thrown(e)),Err(Fault::Local(e))=>Err(e)}
}
'''
def prepare_runtime(s):
    s=one(s,'    source_proof_property_initialized: bool,','''    source_proof_property_initialized: bool,
    source_clearlist_lists: Vec<(V,V)>,
    source_clearlist_banlist: V,
    source_clearlist_xpub_cache: Vec<(V,V)>,
    source_clearlist_roots: Vec<(V,V)>,
    source_clearlist_library: crate::bip32_public::SourceLibrary,
    source_clearlist_library_locked: bool,''')
    s=one(s,'            source_proof_property_initialized: false,','''            source_proof_property_initialized: false,
            source_clearlist_lists: vec![],
            source_clearlist_banlist: V::Array(["US","KP","SY","RU","IR","CU"].into_iter().map(s).collect()),
            source_clearlist_xpub_cache: vec![],
            source_clearlist_roots: vec![],
            source_clearlist_library: crate::bip32_public::SourceLibrary::Litecoin,
            source_clearlist_library_locked: false,''')
    s=one(s,'        let target = call.target.as_str();','''        let target = call.target.as_str();
        if self.main_callable_enabled() {
            if target=="SourceClearList.configureLibrary" {return self.source_clearlist_configure_library(a);}
            if let Some(method)=target.strip_prefix("ClearList.") {return self.source_clearlist_call(method,a);}
            if let Some(method)=target.strip_prefix("Logic.") {if ["createClearList","issueOrRevokeAttestation","updateBannedCountries"].contains(&method){return self.source_clearlist_logic(method,a);}}
        }''')
    s=one(s,'        if arguments.get(1) != Some(&n(18.0))\n','        if arguments.get(1) != Some(&n(18.0))\n            && !(self.core.main_callable_enabled() && [7.,9.].iter().any(|kind|arguments.get(1)==Some(&n(*kind))))\n')
    s=one(s,'                let logic = if params.get("valid") == V::Bool(true)\n','                let logic = if params.get("valid")==V::Bool(true) && self.core.main_callable_enabled() && [7.,9.].iter().any(|kind|arguments.get(1)==Some(&n(*kind))) { self.source_clearlist_raw_logic(&arguments[1],&params)? } else if params.get("valid") == V::Bool(true)\n')
    s=one(s,'        Ok(value)\n    }\n    pub fn invoke_dependency(','''        if self.core.main_callable_enabled(){set(&mut value,"clearlistLifecycle",self.core.source_clearlist_state()).map_err(|_|SourceRuleError::InvalidInput)?;}
        Ok(value)
    }
    pub fn invoke_dependency(''')
    sync='''(self.main_callable_enabled() && (call.target=="SourceClearList.configureLibrary" || matches!(call.target.as_str(),"ClearList.deriveAddressesFromXpub"|"ClearList.registerXpubForRoot"|"ClearList.verifyMerkleProof"|"ClearList.buildMerkleTree"|"ClearList.generateMerkleProof")))'''
    s=one(s,'        ) || (self.lower_lifecycle_enabled() && call.target == "Oracle.getInstance")','        ) || '+sync+'\n            || (self.lower_lifecycle_enabled() && call.target == "Oracle.getInstance")')
    return s+'\ninclude!("source_lower_clearlist_impl.rs");\n'
