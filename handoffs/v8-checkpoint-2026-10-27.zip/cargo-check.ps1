param([Parameter(ValueFromRemainingArguments = $true)][string[]]$CargoArguments)
$ErrorActionPreference = 'Stop'
$taskMsvc = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207'
$taskSdk = 'C:\Program Files (x86)\Windows Kits\10\Lib\10.0.26100.0'
$taskRust = 'C:\Users\patri\.rustup\toolchains\1.90.0-x86_64-pc-windows-msvc\bin'
$env:PATH = "$taskRust;$taskMsvc\bin\Hostx64\x64;$env:PATH"
$env:LIB = "$taskMsvc\lib\x64;$taskSdk\ucrt\x64;$taskSdk\um\x64"
$env:RUSTUP_TOOLCHAIN = '1.90.0-x86_64-pc-windows-msvc'
$env:CARGO_HOME = 'C:\Users\patri\Documents\Codex\2026-10-26\go\work\cargo-home'
$env:RUSTC = "$taskRust\rustc.exe"
$env:RUSTDOC = "$taskRust\rustdoc.exe"
& "$taskRust\cargo.exe" @CargoArguments
exit $LASTEXITCODE
