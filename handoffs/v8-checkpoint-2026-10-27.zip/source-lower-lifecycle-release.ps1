$ErrorActionPreference='Stop'
$taskWork='C:/Users/patri/Documents/Codex/2026-10-26/go/work'
$env:CARGO_INCREMENTAL='0'
$env:CARGO_BUILD_JOBS='4'
& "$taskWork/cargo-check.ps1" -CargoArguments @('build','--frozen','--release','--all-targets','--target-dir',"$taskWork/source-settlement-target") 2>&1 | Tee-Object "$taskWork/source-lower-lifecycle-release.log"
if($LASTEXITCODE -ne 0){throw 'Combined source-index/distribution release failed'}
