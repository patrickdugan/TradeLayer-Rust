$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\Users\patri\Documents\Codex\2026-10-26\go'
$taskMsvc = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207'
$taskSdk = 'C:\Program Files (x86)\Windows Kits\10\Lib\10.0.26100.0'
$taskRust = 'C:\Users\patri\.rustup\toolchains\1.90.0-x86_64-pc-windows-msvc\bin'
$env:PATH = "$taskRust;$taskMsvc\bin\Hostx64\x64;$env:PATH"
$env:LIB = "$taskMsvc\lib\x64;$taskSdk\ucrt\x64;$taskSdk\um\x64"
New-Item -ItemType Directory -Path "$taskRoot\work\v7-fixture-capture" -Force | Out-Null
& "$taskRust\rustc.exe" --edition 2021 "$taskRoot\work\freeze-source-v7.rs" --extern "tradelayer_core=$taskRoot\work\source-settlement-target\release\libtradelayer_core.rlib" -L "dependency=$taskRoot\work\source-settlement-target\release\deps" -o "$taskRoot\work\v7-fixture-capture\freeze-source-v7.exe"
if ($LASTEXITCODE -ne 0) { throw 'V7 fixture generator compile failed' }
Push-Location $taskRoot
try {
 & "$taskRoot\work\v7-fixture-capture\freeze-source-v7.exe" 2>&1 | Tee-Object -FilePath "$taskRoot\work\v7-fixture-capture\capture.log"
 if ($LASTEXITCODE -ne 0) { throw 'V7 fixture capture failed' }
} finally { Pop-Location }
