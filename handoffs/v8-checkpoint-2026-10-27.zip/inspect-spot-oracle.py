from pathlib import Path
import json,struct
p=Path(__file__).resolve().parent/'next-lower-spot/fixtures/lower_spot_proof10.jsonl'
def decode(v):
 tag=v[0]
 if tag=='undefined':return {'undefined':True}
 if tag=='null':return None
 if tag in ['boolean','string']:return v[1]
 if tag=='number':return v[1] if v[1] in ['NaN','Infinity','-Infinity'] else struct.unpack('>d',bytes.fromhex(v[1]))[0]
 if tag=='bignumber':return {'bignumber':v[1]}
 if tag=='array':return [decode(x) for x in v[1]]
 if tag=='object':return {k:decode(x) for k,x in v[1]}
 raise ValueError(tag)
rows=[decode(json.loads(line)) for line in p.read_text(encoding='utf-8').splitlines()]
row=rows[3]
print(json.dumps({'name':row['name'],'tally':row['state']['tally'],'bookInstances':row['state']['orderbookInstances'],'tradeRows':[x for x in row['state']['tables'] if x['name'] in ['tradeHistory','orderBooks']],'calls':[x['target'] for x in row['effects'] if x.get('kind')=='source-function']},ensure_ascii=True,indent=2))
