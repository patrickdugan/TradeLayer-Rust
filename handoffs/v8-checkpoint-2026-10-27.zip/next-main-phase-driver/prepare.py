"""WORK ONLY MainCallableV8 transform; no repository application or compiler."""
from pathlib import Path
import argparse
import hashlib
import json

STAGE = Path(__file__).resolve().parent
WORK = STAGE.parent
REPO = WORK.parent / 'outputs' / 'TradeLayer-Rust'


def one(source, before, after):
    if source.count(before) != 1:
        raise ValueError(f'Main anchor count {source.count(before)}: {before[:100]}')
    return source.replace(before, after, 1)


def prepare_policy(source):
    source = one(source, '    LowerLifecycleV7,\n', '    LowerLifecycleV7,\n    MainCallableV8,\n')
    source = one(source, 's(if self.core.lower_lifecycle_enabled() {',
                 's(if self.core.main_callable_enabled() {\n                    "MainCallableV8"\n                } else if self.core.lower_lifecycle_enabled() {')
    inherited = '                | SourceContractRuntimePolicy::LowerLifecycleV7\n'
    if source.count(inherited) != 5:
        raise ValueError('Main V7 inherited helper count')
    source = source.replace(inherited, inherited + '                | SourceContractRuntimePolicy::MainCallableV8\n')
    return one(source, '        self.policy == SourceContractRuntimePolicy::LowerLifecycleV7\n    }',
               '        matches!(self.policy,SourceContractRuntimePolicy::LowerLifecycleV7|SourceContractRuntimePolicy::MainCallableV8)\n    }\n    fn main_callable_enabled(&self)->bool {self.policy==SourceContractRuntimePolicy::MainCallableV8}')


def prepare_runtime(source):
    """Apply after prepare_policy. Later lower raw fragments may extend the
    unchanged `if arguments.get(1)` admission anchor and `let logic = if`
    dispatch anchor now shared by the legacy public and Main callers."""
    source = one(source, '    position_identity_active: bool,\n', '''    position_identity_active: bool,
    main_activation: crate::activation::SourceActivation,
    main_activation_profile: String,
    main_activation_locked: bool,
    main_height_job: Option<SourceMainHeightJob>,
    main_height_rejections: Vec<crate::validity_source::SourceException>,
''')
    source = one(source, '            position_identity_active: false,\n', '''            position_identity_active: false,
            main_activation: crate::activation::SourceActivation::new(),
            main_activation_profile: "source-registry".into(),
            main_activation_locked: false,
            main_height_job: None,
            main_height_rejections: vec![],
''')
    source = one(source, '''        Ok(value)
    }
    pub fn invoke_dependency(''', '''        if self.core.main_callable_enabled() {
            set(&mut value,"mainCallable",self.core.source_main_state()).map_err(|_|SourceRuleError::InvalidInput)?;
        }
        Ok(value)
    }
    pub fn invoke_dependency(''')
    source = one(source, '''        for v in &call.arguments {
            v.validate()?
        }
        let before = self.clone();
        self.core.queue_context''', '''        for v in &call.arguments {
            v.validate()?
        }
        if self.core.main_callable_enabled() && call.target.starts_with("Main.") {
            return self.source_main_invoke(call);
        }
        let before = self.clone();
        self.core.queue_context''')
    source = one(source, '''        let target = call.target.as_str();
        if self.lower_lifecycle_enabled() {''', '''        let target = call.target.as_str();
        if self.main_callable_enabled() {
            if target=="SourceMain.configure" {return self.source_main_configure(a);}
            if let Some(method)=target.strip_prefix("Activation.") {
                self.main_activation_locked=true;
                if self.main_activation_profile=="source-registry" {return self.source_main_activation(method,a);}
            }
        }
        if self.lower_lifecycle_enabled() {''')
    source = one(source, '''        if self.lifecycle_enabled() && name == "volumeIndex" {
            self.source_channel_price_after_database()?;
        }
        result''', '''        if self.lifecycle_enabled() && name == "volumeIndex" {
            self.source_channel_price_after_database()?;
        }
        if self.main_callable_enabled() {self.source_main_after_database()?;}
        result''')
    source = one(source, '''        if matches!(
            call.target.as_str(),
            "uuid.v4"''', '''        if self.main_callable_enabled() && call.target=="SourceMain.configure" {
            return match result {Ok(v)=>Ok(DependencyReturn::Immediate(v)),Err(Fault::Thrown(e))=>Ok(DependencyReturn::Throw(e)),Err(Fault::Local(e))=>Err(e)};
        }
        if self.main_callable_enabled() && self.main_activation_profile=="source-registry" && call.target.starts_with("Activation.") {
            let sync=matches!(call.target.as_str(),"Activation.getAdmin"|"Activation.getActivationBlock"|"Activation.initializeTxRegistry");
            return match result {
                Ok(v)=>Ok(if sync {DependencyReturn::Immediate(v)}else{DependencyReturn::Pending(v)}),
                Err(Fault::Thrown(e))=>Ok(if sync {DependencyReturn::Throw(e)}else{DependencyReturn::PendingThrow(e)}),
                Err(Fault::Local(e))=>Err(e),
            };
        }
        if matches!(
            call.target.as_str(),
            "uuid.v4"''')
    start = source.index('    fn execute_contract_inner(\n')
    decode_start = source.index('        self.last_parameters = None;\n', start)
    decode_end = source.index('        match result.outcome {\n', decode_start)
    prefix = source[decode_start:decode_end]
    source = source[:decode_start] + '        let result=self.source_main_decode_reused(arguments)?;\n' + source[decode_end:]
    source = one(source, '        match result.outcome {\n', '        match result {\n')
    logic_start = source.index('                let logic = if params.get("valid")', start)
    logic_end = source.index('                match logic {\n', logic_start)
    logic = source[logic_start:logic_end]
    source = source[:logic_start] + '                let logic=self.source_main_logic_reused(arguments,&params)?;\n' + source[logic_end:]
    helpers = '''impl SourceContractRuntime {
    fn source_main_decode_reused(&mut self,arguments:&[V])->Result<crate::types_source::TypesOutcome,SourceRuleError> {
''' + prefix + '''        Ok(result.outcome)
    }
    fn source_main_logic_reused(&mut self,arguments:&[V],params:&V)->Result<SourceOutcome,SourceRuleError> {
''' + logic + '''        Ok(logic)
    }
}
'''
    return source + '\n' + helpers + '\ninclude!("source_main_callable_impl.rs");\n'


def prepare_replay(source):
    source = one(source, 'const MAGIC_V7: &[u8; 5] = b"TLCR\\x07";', 'const MAGIC_V7: &[u8; 5] = b"TLCR\\x07";\nconst MAGIC_V8: &[u8; 5] = b"TLCR\\x08";')
    source = one(source, '''            SourceContractRuntimePolicy::LowerLifecycleV7 => {
                b"TradeLayer/SourceContractBootstrap/v7/".to_vec()
            }''', '''            SourceContractRuntimePolicy::LowerLifecycleV7 => {
                b"TradeLayer/SourceContractBootstrap/v7/".to_vec()
            }
            SourceContractRuntimePolicy::MainCallableV8 => {b"TradeLayer/SourceContractBootstrap/v8/".to_vec()}''')
    source = one(source, '            SourceContractRuntimePolicy::LowerLifecycleV7 => MAGIC_V7.to_vec(),', '            SourceContractRuntimePolicy::LowerLifecycleV7 => MAGIC_V7.to_vec(),\n            SourceContractRuntimePolicy::MainCallableV8 => MAGIC_V8.to_vec(),')
    return one(source, '            magic if magic == MAGIC_V7 => SourceContractRuntimePolicy::LowerLifecycleV7,', '            magic if magic == MAGIC_V7 => SourceContractRuntimePolicy::LowerLifecycleV7,\n            magic if magic == MAGIC_V8 => SourceContractRuntimePolicy::MainCallableV8,')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=REPO)
    parser.add_argument('--output', type=Path, default=STAGE / 'preview')
    args = parser.parse_args()
    repo, output = args.repo.resolve(), args.output.resolve()
    if not output.is_relative_to(WORK.resolve()) or output == WORK.resolve() or output.is_relative_to(repo) or repo.is_relative_to(output):
        raise ValueError('work-only preview required')
    inputs = {p:p.read_bytes() for p in sorted((repo/'src').rglob('*')) if p.is_file()}
    inputs.update({p:p.read_bytes() for folder in ['src','tests','docs','scripts','fixtures'] for p in sorted((STAGE/folder).rglob('*')) if p.is_file()})
    inputs[STAGE/'prepare.py']=(STAGE/'prepare.py').read_bytes()
    payload={p.relative_to(repo).as_posix():v for p,v in inputs.items() if p.is_relative_to(repo)}
    payload['src/source_contract_runtime.rs']=prepare_runtime(prepare_policy(payload['src/source_contract_runtime.rs'].decode().replace('\r\n','\n'))).encode()
    payload['src/source_contract_replay.rs']=prepare_replay(payload['src/source_contract_replay.rs'].decode().replace('\r\n','\n')).encode()
    payload.update({p.relative_to(STAGE).as_posix():v for p,v in inputs.items() if p.is_relative_to(STAGE) and p.name!='prepare.py'})
    if any(p.read_bytes()!=v for p,v in inputs.items()):
        raise ValueError('input changed during preview')
    for name,data in payload.items():
        target=output/name
        if not target.resolve().is_relative_to(output):
            raise ValueError('preview symlink escape')
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
    (output/'manifest.json').write_text(json.dumps({'policy':'MainCallableV8','inputs':{str(p):hashlib.sha256(v).hexdigest() for p,v in inputs.items()},'payloads':{p:hashlib.sha256(v).hexdigest() for p,v in payload.items()}},indent=2)+'\n')
    print(f'WORK ONLY {output}: {len(payload)} payloads; no repository writes or build')


if __name__=='__main__':
    main()
