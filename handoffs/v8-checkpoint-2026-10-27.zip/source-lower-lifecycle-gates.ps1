$ErrorActionPreference='Stop'
$taskWork='C:/Users/patri/Documents/Codex/2026-10-26/go/work'
$taskRust='C:/Users/patri/.rustup/toolchains/1.90.0-x86_64-pc-windows-msvc/bin'
$taskTarget="$taskWork/global-clearing-target"
$env:CARGO_INCREMENTAL='0';$env:CARGO_PROFILE_DEV_DEBUG='0';$env:CARGO_BUILD_JOBS='4'
$env:TRADELAYER_JS_ROOT='C:/Users/patri/Documents/Codex/tradelayer.js'
$env:PATH="$taskRust;$env:PATH"
$env:TMP="$taskWork/cargo-gate-tmp";$env:TEMP="$taskWork/cargo-gate-tmp"
Remove-Item Env:NODE_OPTIONS -ErrorAction SilentlyContinue
function Invoke-GlobalGate([string]$Label,[string[]]$Arguments){
 & "$taskWork/cargo-check.ps1" -CargoArguments $Arguments 2>&1 | Tee-Object "$taskWork/source-lower-lifecycle-$Label.log"
 if($LASTEXITCODE -ne 0){throw "$Label gate failed: $LASTEXITCODE"}
}
Invoke-GlobalGate 'format' @('fmt','--all','--','--check')
$taskIncluded=@()
foreach($line in Get-Content '.github/workflows/ci.yml'){if($line -match 'run: rustfmt --check --edition 2021 (.+)$'){$taskIncluded+=$Matches[1].Split(' ',[StringSplitOptions]::RemoveEmptyEntries)}}
& "$taskRust/rustfmt.exe" --check --edition 2021 @taskIncluded 2>&1 | Tee-Object "$taskWork/source-lower-lifecycle-includes-format.log"
if($LASTEXITCODE -ne 0){throw 'Included format failed'}
Invoke-GlobalGate 'clippy' @('clippy','--frozen','--all-targets','--target-dir',$taskTarget,'--','-D','warnings')
Invoke-GlobalGate 'full-tests' @('test','--frozen','--all-targets','--target-dir',$taskTarget)
Invoke-GlobalGate 'doctest' @('test','--frozen','--doc','--target-dir',$taskTarget)
python -B scripts/check_rust_supply_chain.py 2>&1 | Tee-Object "$taskWork/source-lower-lifecycle-supply-policy.log"
if($LASTEXITCODE -ne 0){throw 'Supply policy failed'}
python -B -m unittest discover -s tests -p test_rust_supply_chain.py -v 2>&1 | Tee-Object "$taskWork/source-lower-lifecycle-supply-mutations.log"
if($LASTEXITCODE -ne 0){throw 'Supply mutation tests failed'}
python -B scripts/check_logic_inventory.py 2>&1 | Tee-Object "$taskWork/source-lower-lifecycle-inventory.log"
if($LASTEXITCODE -ne 0){throw 'Logic inventory failed'}
python -B -m unittest discover -s tests -p test_bitcoin_core_rpc_stream.py -v 2>&1 | Tee-Object "$taskWork/source-lower-lifecycle-bitcoin-core-bridge.log"
if($LASTEXITCODE -ne 0){throw 'Bitcoin Core bridge Python tests failed'}
$env:TL_TXINDEX_LOCKED_DEPENDENCY='1'
$env:TL_SOURCE_BN_VERSION='9.1.2'
$env:TL_BIGNUMBER_LOCK_ROOT="$taskWork/bignumber-lock-reference"
$env:NODE_OPTIONS='--require C:/Users/patri/Documents/Codex/2026-10-26/go/outputs/TradeLayer-Rust/scripts/bignumber_lock_reference.cjs'
& node -e 'require("./scripts/legacy_numeric_oracle.cjs").loadBigNumber();' 2>&1 | Tee-Object "$taskWork/source-lower-lifecycle-locked-preloader.log"
if($LASTEXITCODE -ne 0){throw 'Locked preloader failed'}
Invoke-GlobalGate 'locked-reference' @('test','--frozen','--target-dir',$taskTarget,'--test','margin_map_source_clearing','--test','source_clearing_funding','--test','source_insurance_lifecycle','--test','source_iou_settlement','--test','source_clearing_liquidation','--test','source_clearing_expiry','--test','source_clearing_global','--test','source_clearing_supply','--test','source_contract_runtime_signatures','--test','source_contract_replay_versions','--test','source_contract_runtime','--test','source_contract_replay','--test','source_contract_registry_lifecycle','--test','source_contract_lifecycle_versions','--test','source_channel_financial','--test','source_channel_logic','--test','source_transition_witness','--test','source_option_trade','--test','source_synthetic_lifecycle','--test','source_option_lifecycle_versions','--test','source_derivative_exercise','--test','source_option_indexes','--test','source_option_adjustment_failures','--test','source_distribution_lifecycle','--test','source_txindex_owner','--test','source_proof_lifecycle','--test','source_proof_lifecycle_versions','--test','source_procedural_bitvm','--test','source_liquidity_rewards','--test','source_lifecycle_transition_witness','--test','source_tail_lifecycle','--test','source_lower_property_lifecycle','--test','source_lower_oracle_lifecycle','--test','source_lower_lifecycle_versions')
Remove-Item Env:NODE_OPTIONS -ErrorAction SilentlyContinue
foreach($taskArgs in @(@('--proof10','--check'),@('--proof10','--lock','--check'),@('--check'),@('--lock','--check'))){
 & node scripts/main_phase_vectors.cjs @taskArgs 2>&1 | Tee-Object -Append "$taskWork/source-lower-lifecycle-main-evidence.log"
 if($LASTEXITCODE -ne 0){throw 'Main evidence regeneration failed'}
}
Write-Output 'SOURCE_LOWER_LIFECYCLE_TEST_GATES_PASSED'
