"""WORK ONLY send/commit fragment after MainCallableV8 factorization."""
def one(source,before,after):
    if source.count(before)!=1:raise ValueError(f'Send/commit anchor count {source.count(before)}: {before[:100]}')
    return source.replace(before,after,1)

def prepare_runtime(source):
    source=one(source,'    position_identity_active: bool,\n','    position_identity_active: bool,\n    source_send_tally_instance_initialized: bool,\n    source_send_tally_read_job: Option<SourceSendTallyReadJob>,\n')
    source=one(source,'            position_identity_active: false,\n','            position_identity_active: false,\n            source_send_tally_instance_initialized: false,\n            source_send_tally_read_job: None,\n')
    source=one(source,'        let target = call.target.as_str();\n','''        let target = call.target.as_str();
        if self.main_callable_enabled() {
            if ["Tally.getTotalForProperty","Tally.getTotalTally"].contains(&target) {self.source_send_tally_instance_initialized=true;}
            if let Some(method)=target.strip_prefix("Tally.") {if ["getInstance","getAddressBalances","instanceGetAddressBalances"].contains(&method){return self.source_send_tally(method,a);}}
            if let Some(method)=target.strip_prefix("Logic.") {if ["sendToken","sendSingle","sendAll","processSend","vestingSend","calculateVestingMovement","roundToEightDecimals","commitToken"].contains(&method){return self.source_send_commit_logic(method,a);}}
        }
''')
    source=one(source,'        if arguments.get(1) != Some(&n(18.0))\n','''        if arguments.get(1) != Some(&n(18.0))
            && !(self.core.main_callable_enabled() && [2.,4.].iter().any(|kind|arguments.get(1)==Some(&n(*kind))))
''')
    source=one(source,'                let logic = ','''                let logic = if params.get("valid")==V::Bool(true) && self.core.main_callable_enabled() && [2.,4.].iter().any(|kind|arguments.get(1)==Some(&n(*kind))){self.source_send_commit_raw_logic(&arguments[1],params)?} else ''')
    source=one(source,'        if self.global_clearing_enabled() {\n            self.source_history_after_database(name)?;','''        if self.main_callable_enabled() && name=="tallyMap" {self.source_send_read_after_database()?;}
        if self.global_clearing_enabled() {
            self.source_history_after_database(name)?;''')
    source=one(source,'        Ok(value)\n    }\n    pub fn invoke_dependency(','''        if self.core.main_callable_enabled(){set(&mut value,"sendCommit",self.core.source_send_commit_state()).map_err(|_|SourceRuleError::InvalidInput)?;}
        Ok(value)
    }
    pub fn invoke_dependency(''')
    source=one(source,'        if matches!(\n            call.target.as_str(),\n            "uuid.v4"','''        if self.main_callable_enabled() && matches!(call.target.as_str(),"Logic.calculateVestingMovement"|"Logic.roundToEightDecimals"|"Tally.instanceGetAddressBalances") {
            return match result {Ok(v)=>Ok(DependencyReturn::Immediate(v)),Err(Fault::Thrown(e))=>Ok(DependencyReturn::Throw(e)),Err(Fault::Local(e))=>Err(e)};
        }
        if matches!(
            call.target.as_str(),
            "uuid.v4"''')
    return source+'\ninclude!("source_lower_send_commit_impl.rs");\n'

def prepare_accounting(source):
    return one(source,'''        match result {
            Err(Fault::Thrown(_)) => Ok(V::Undefined),
            other => other,
        }
    }
    fn tally_get''','''        let result=match result {
            Err(Fault::Thrown(_)) => Ok(V::Undefined),
            other => other,
        };
        if self.main_callable_enabled(){self.source_send_read_after_load()?;}
        result
    }
    fn tally_get''')
