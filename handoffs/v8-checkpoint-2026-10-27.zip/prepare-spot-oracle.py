from pathlib import Path
w=Path(__file__).resolve().parent
p=w/'next-lower-spot';(p/'scripts').mkdir(parents=True,exist_ok=True);(p/'fixtures').mkdir(exist_ok=True)
s=(w/'next-lower-send-commit/scripts/lower_send_commit_vectors.cjs').read_text(encoding='utf-8')
s=s[:s.index('(async()=>{')]
s=s.replace("const A='1BoatSLRHtKNngkdXEeobR76b53LETtpyT'","const txids={'raw5-queued':'a'.repeat(64),'raw5-counter':'b'.repeat(64),'direct-stop-post':'c'.repeat(64)};const A='1BoatSLRHtKNngkdXEeobR76b53LETtpyT'")
s=s.replace("const args=[name,type,'tl'","const args=[txids[name]||name,type,'tl'")
s=s.replace("B='LKQa26zKBtyM2kw6aMEYyj4fCbCqxJyrPw'","B='1BitcoinEaterAddressDontSendf59kuE'")
s=s.replace('SEND_COMMIT_REPO','SPOT_REPO').replace("return {adapters,context,storage,tables,copy,types,logic,Orderbook,effects","return {instanceId,instances,adapters,context,storage,tables,copy,types,logic,Orderbook,effects")
start=s.index('function bindRpc(){');end=s.index('function fail(',start)
s=s[:start]+r'''function bindRpc(){
 const source=fs.readFileSync(path.join(root,'fixtures/source_channel_txutils_reference.txt'),'utf8');assert.equal(crypto.createHash('sha256').update(source).digest('hex'),'38fbc7b5c1dc4d187867238b5ea00bc165c855e9ccfbc20c48141cd4796ac8a3');
 const moduleRoot=process.env.TRADELAYER_JS_ROOT||path.resolve(root,'../../../../tradelayer.js'),external=Module.createRequire(path.join(moduleRoot,'package.json')),own={exports:{}};
 const client={async getRawTransaction(...args){const value=structuredClone(e.table('sourceRpcTransactions').find(row=>row.txid===args[0])?.transaction);e.effects.push({kind:'rpc',method:'Client.getRawTransaction',args,returned:structuredClone(value)});return value;},async getBlock(...args){const value=structuredClone(e.table('sourceRpcBlocks').find(row=>row.hash===args[0])?.block);e.effects.push({kind:'rpc',method:'Client.getBlock',args,returned:structuredClone(value)});return value;}};
 const wrapper=vm.runInContext('(function(exports,require,module){\n'+source+'\n})',e.context,{filename:'pinned/txUtils.js'});
 wrapper(own.exports,key=>key==='bitcore-lib-ltc'?external(key):key==='bignumber.js'?BN:key==='./txEncoder.js'?e.load('txEncoder'):key==='./consensus.js'?e.load('consensus'):key==='./client'?{getInstance(){return Promise.resolve(client)}}:(()=>{throw Error('Unmapped TxUtils require '+key)})(),own);
 for(const key of ['getRawTransaction','getBlockHeight'])e.adapters['./txUtils'][key]=function(...args){e.effects.push({kind:'source-function',target:'TxUtils.'+key,args:structuredClone(args)});return Reflect.apply(own.exports[key],own.exports,args);};
}
async function reset(name,options={}){
 e=driver.exports.environment(options);lastParams=undefined;unhandled=[];
 const rows=JSON.parse(e.table('tallyMap')[0].data);const shape=rows[0][1][7];for(const row of rows)row[1][1]=structuredClone(shape);if(!rows.some(row=>row[0]===B))rows.push([B,{1:structuredClone(shape),7:structuredClone(shape)}]);e.table('tallyMap')[0].data=JSON.stringify(rows);
 e.table('sourceRpcTransactions').push(...['raw5-queued','raw5-counter','direct-stop-post'].map(name=>({txid:txids[name],transaction:{blockhash:'spot-block',vin:[],vout:[]}})));
 e.table('sourceRpcBlocks').push({hash:'spot-block',block:{height:9}});bindRpc();
 for(const method of ['onChainTokenToToken','cancelOrder'])observe(e.logic,method,'Logic.'+method);
 observe(e.Orderbook,'queueOnChainTokenOrder','Orderbook.queueOnChainTokenOrder');
 for(const method of ['cancelAllTokenOrders','cancelTokenOrderByTxid','cancelTokenBuyOrdersByPrice','cancelTokenSellOrdersByPrice','cancelAllContractOrders','cancelContractOrderByTxid','cancelOrdersByCriteria','saveOrderBook','loadOrderBook','getOrdersForAddress','addTokenOrder','matchTokenOrders','processTokenMatches']){
  const original=e.Orderbook.prototype[method];if(typeof original!=='function')continue;e.Orderbook.prototype[method]=function(...args){const id=e.instanceId(this);e.effects.push({kind:'source-function',target:'Orderbook.instance.'+method,instance:id,args:structuredClone(args)});return Reflect.apply(original,this,args);};
 }
 await flush();e.effects.length=0;emit(name,{reset:options},{outcome:{returned:undefined}});
}
'''+s[end:]
s=s.replace("receiver=ns==='Logic'?e.logic:e.load('tally')","receiver=ns==='Logic'?e.logic:ns==='Orderbook'?e.Orderbook:e.load('tally')")
s=s.replace('lastParams,unhandled,unsupported:e.state().unsupported','orderbookInstances:e.copy(e.state().instances),lastParams,unhandled,unsupported:e.state().unsupported')
s+=r'''(async()=>{
 await reset('first-ten');
 await raw('raw5-queued',5,'7,1,'+amount(1)+','+amount(1)+',0,0');
 await raw('raw5-counter',5,'1,7,'+amount(1)+','+amount(1)+',0,0',B);
 await call('actual-token-queue-drain','Orderbook.processQueuedOnChainOrdersForBlock',[10]);
 await raw('raw6-no-sender-transport',6,'0,7,1,0,,buy');
 await call('direct-cancel-empty-all','Logic.cancelOrder',[A,false,7,1,true,{},10]);
 await call('direct-cancel-plural-missing','Logic.cancelOrder',[A,false,7,1,false,{txid:'a'.repeat(64)},10]);
 await call('direct-contract-cancel-empty','Logic.cancelOrder',[A,true,1,null,true,{},10]);
 await call('direct-cancel-null-params','Logic.cancelOrder',[A,false,7,1,false,null,10]);
 await call('direct-stop-post-original-rpc','Logic.onChainTokenToToken',[A,7,1,1,2,txids['direct-stop-post'],10,true,true]);
 await call('actual-stop-token-drain','Orderbook.processQueuedOnChainOrdersForBlock',[10]);
})().then(()=>{const output=records.map(record=>JSON.stringify(tag(record))).join('\n')+'\n';const destination=path.resolve(__dirname,'../fixtures/lower_spot_proof10.jsonl');if(flags.includes('--stdout')){process.stdout.write(output);return;}if(flags.includes('--check'))assert.equal(fs.readFileSync(destination,'utf8'),output);else fs.writeFileSync(destination,output);console.log(JSON.stringify({observations:records.length,calls:records.filter(r=>r.command.raw||r.command.target).length,version:lock?'9.1.2':'9.3.1',sha256:crypto.createHash('sha256').update(output).digest('hex'),summary:records.map(r=>({name:r.name,result:r.result,unhandled:r.state.unhandled}))},null,2));}).catch(error=>{console.error(error);process.exitCode=1;});
'''
# Raw strings preserve JS escapes; source wrapper needs real newline bytes.
s=s.replace("{\\\\n'+source+'\\\\n})","{\\n'+source+'\\n})")
s=s.replace("join('\\\\n')+'\\\\n'","join('\\n')+'\\n'")
(p/'scripts/lower_spot_vectors.cjs').write_text(s,encoding='utf-8',newline='\n')
print('Created work-only spot source driver; no root edits or Rust claims.')
