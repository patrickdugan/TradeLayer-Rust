use tradelayer_core::source_contract_replay::{SourceContractCommand as C, SourceContractReplay};
use tradelayer_core::source_contract_runtime::SourceContractRuntimePolicy as P;
use tradelayer_core::validity_source::{DependencyCall, SourceValue as V};
fn s(v: &str) -> V { V::String(v.into()) }
fn n(v: f64) -> V { V::number(v) }
fn obj(v: &[(&str,V)]) -> V { V::Object(v.iter().map(|(k,v)|(k.to_string(),v.clone())).collect()) }
fn call(target: &str, arguments: Vec<V>) -> C { C::Invoke(DependencyCall {target: target.into(), arguments}) }
fn main() {
    let mut r=SourceContractReplay::with_policy(P::LowerLifecycleV7).unwrap();
    let commands=[
        C::SetHeight(n(10.)),
        call("SourceEnvironment.configure",vec![obj(&[("TL_BITVM_CHALLENGE_BLOCKS",s("6")),("TL_BITVM_MAX_PENDING_ESCROW",s("100")),("LIQUIDITY_REWARD_PROPERTY_ALLOWLIST",s("3"))])]),
        call("SourceArtifacts.configure",vec![obj(&[("C:/source-fixture/bundle.json",s("7b7d"))])]),
        call("SourceArtifacts.configure",vec![obj(&[])]),
        call("Property.getInstance",vec![]),
        call("Procedural.upsertTemplate",vec![s("T"),obj(&[("templateHash",s("AbCd")),("marker",n(6.))])]),
        call("Procedural.upsertContract",vec![s("C"),s("T"),s("OPEN"),obj(&[("sourceFixture",V::Bool(true))])]),
        call("BitvmCache.open",vec![obj(&[("cacheId",s("v6-cache")),("propertyId",n(3.)),("amount",n(4.)),("challengeBlocks",n(6.))]),obj(&[("senderAddress",s("alice")),("dlcRef",s("C")),("stateHash",s("state")),("block",n(10.))])]),
        call("BitvmRisk.onCacheOpen",vec![obj(&[("propertyId",n(3.)),("amount",n(4.)),("dlcRef",s("C")),("block",n(10.))])]),
        call("Oracle.recordStake",vec![n(7.),s("alice"),n(3.),n(5.),n(10.)]),
        call("Tally.updateBalance",vec![s("alice"),n(3.),n(12.),n(0.),n(0.),n(0.),s("v6-fixture"),n(10.)]),
        call("Logic.queueLiquidityReward",vec![s("alice"),n(1.25),n(10.),s("queue-v6")]),
        call("Vaults.createVault",vec![n(7.),n(1.)]),
        call("Vaults.registerSyntheticToken",vec![n(9.),n(1.),n(7.)]),
    ];
    for c in commands { let receipt=r.apply(c).unwrap(); println!("{:?} effects={}",receipt.outcome,receipt.effects.len()); }
    for c in [
        call("Logic.tokenIssue",vec![s("alice"),n(100.),s("V7FIX"),s("url"),n(0.),V::Bool(true),s("backup"),V::Bool(false),n(10.),V::Null]),
        call("Logic.grantManagedToken",vec![n(1.),n(2.),s("alice"),s("alice"),n(10.)]),
        call("Logic.redeemManagedToken",vec![n(1.),n(1.),s("alice"),n(10.)]),
        call("Logic.createOracle",vec![s("alice"),s("V7ORACLE"),s("url"),s("backup"),V::Array(vec![]),n(1.)]),
        call("Logic.publishOracleData",vec![n(1.),n(5.),n(6.),n(4.),n(5.),n(10.)]),
    ] {let receipt=r.apply(c).unwrap();println!("{:?} effects={}",receipt.outcome,receipt.effects.len());}
    for target in ["Main.processTxSet","Main.processTx","Main.blockHandlerMid","ClearList.create","ClearList.updateAdmin","ClearList.attest","Logic.sendToken","Logic.commitToken","Tally.getInstance"] {
        let receipt=r.apply(call(target,vec![])).unwrap(); println!("{:?} effects={}",receipt.outcome,receipt.effects.len());
    }
    for kind in [0.,2.,3.,4.,5.,6.,7.,9.,10.] {
        let receipt=r.apply(C::ExecuteContract(vec![s("future-v7"),n(kind),s("tl"),s(""),s("alice"),V::Null,n(0.),n(0.),n(10.)])).unwrap();
        println!("{:?} effects={}",receipt.outcome,receipt.effects.len());
    }
    let bytes=r.checkpoint().unwrap();
    let pin=r.head();
    let restored=SourceContractReplay::from_checkpoint(&bytes,pin).unwrap();
    assert_eq!(restored.checkpoint().unwrap(),bytes);
    assert_eq!(restored.runtime().state_value().unwrap(),r.runtime().state_value().unwrap());
    std::fs::write("work/v7-fixture-capture/source_contract_replay_v7.bin",bytes).unwrap();
    println!("HEAD {} {}",pin.commands,pin.commitment.iter().map(|v|format!("{v:02x}")).collect::<String>());
}
